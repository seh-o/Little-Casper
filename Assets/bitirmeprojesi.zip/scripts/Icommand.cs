using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface Icommand 
{
    void execute();
    
}

public class oncoinchangecommand : Icommand
{
    public void execute()
    {
        
    }
}