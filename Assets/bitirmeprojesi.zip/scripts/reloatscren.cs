using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class reloatscren : MonoBehaviour
{
    public void reloadscreen()
    {
        SceneManager.LoadScene("anamen�");
        
    }

    


}
