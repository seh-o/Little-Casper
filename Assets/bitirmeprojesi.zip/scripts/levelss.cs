using System.Collections;
using System.Collections.Generic;
using UnityEngine;
[System.Obsolete]
public class levelss : MonoBehaviour
{
   
    public void Levels(int level)
        {
        Application.LoadLevel(level);
        }
    }
